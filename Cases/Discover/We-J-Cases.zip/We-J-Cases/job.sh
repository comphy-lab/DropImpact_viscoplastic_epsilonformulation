#!/bin/bash
Wes=("14" "15" "16" "18" "20")  #13
Ohs=("0.0025")
J1s="0 0.05 0.1 0.15 0.2 0.25 0.3 0.4"
for We in "${Wes[@]}"; do
    for Oh in "${Ohs[@]}"; do
        cp run_basic.sh run_Oh"$Oh"_We"$We"-1.sh
        sed -i "s/WeVALUE/$We/" run_Oh"$Oh"_We"$We"-1.sh
        sed -i "s/OhVALUE/$Oh/" run_Oh"$Oh"_We"$We"-1.sh
        sed -i "s/JsVALUE/$J1s/" run_Oh"$Oh"_We"$We"-1.sh
        sed -i "s/INDEX/We"$We"-1/" run_Oh"$Oh"_We"$We"-1.sh
        sbatch run_Oh"$Oh"_We"$We"-1.sh
    done
done